self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "c537be26d1bebdc4a968399a0502277d",
    "url": "/index.html"
  },
  {
    "revision": "23e547d467244714ee14",
    "url": "/static/css/2.682ad940.chunk.css"
  },
  {
    "revision": "2384c235f175fe36dfe2",
    "url": "/static/css/main.bfbab844.chunk.css"
  },
  {
    "revision": "23e547d467244714ee14",
    "url": "/static/js/2.ec2bdd22.chunk.js"
  },
  {
    "revision": "9d7baa484de148efea1c408ede69d272",
    "url": "/static/js/2.ec2bdd22.chunk.js.LICENSE.txt"
  },
  {
    "revision": "2384c235f175fe36dfe2",
    "url": "/static/js/main.464d65f1.chunk.js"
  },
  {
    "revision": "2747b914e9a60db2276f",
    "url": "/static/js/runtime-main.c8a21426.js"
  },
  {
    "revision": "1153a9e08d18d85cae3aa83bed290970",
    "url": "/static/media/cover123.1153a9e0.jpg"
  },
  {
    "revision": "b07dc175db13c281f6bb8db6db0b332f",
    "url": "/static/media/home_cover.b07dc175.jpg"
  }
]);